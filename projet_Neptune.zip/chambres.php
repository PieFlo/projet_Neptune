<?php 
session_start();
include('connectionBDD.php');
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Chambres</title>
</head>
<body>

<center>

<h1>Chambres de l'hôtel Neptune</h1>

<p><a href="modifChambres.php">Modification</a> des chambres, pour les administrateurs uniquement !</p>

<p>Voir <a href="equipementChambres.php">l'équipement</a> des chambres.</p>
<br>

<div class="chambre">
<img src="images/chambre1.jpg" alt="Chambre de l'hôtel Neptune" class="img-circle" width="904" height="636"/>
<p>Chambre 1</p>
<br>
<br>
</div>

<div class="chambre">
<img src="images/chambre2.jpg" alt="Chambre de l'hôtel Neptune" class="img-circle" width="904" height="636"/>
<p>Chambre 2</p>
<br>
<br>
</div>

<div class="chambre">
<img src="images/chambre3.jpg" alt="Chambre de l'hôtel Neptune" class="img-circle" width="904" height="636"/>
<p>Chambre 3</p>
<br>
<br>
</div>

<div class="chambre">
<img src="images/chambre4.jpg" alt="Chambre de l'hôtel Neptune" class="img-circle" width="904" height="636"/>
<p>Chambre 4</p>
<br>
<br>
</div>

<div class="chambre">
<img src="images/chambre5.jpg" alt="Chambre de l'hôtel Neptune" class="img-circle" width="904" height="636"/>
<p>Chambre 5</p>
<br>
<br>
</div>

<div class="chambre">
<img src="images/chambre6.jpg" alt="Chambre de l'hôtel Neptune" class="img-circle" width="904" height="636"/>
<p>Chambre 6</p>
<br>
<br>
</div>

<div class="chambre">
<img src="images/chambre7.jpg" alt="Chambre de l'hôtel Neptune" class="img-circle" width="904" height="636"/>
<p>Chambre 7</p>
<br>
<br>
</div>

<div class="chambre">
<img src="images/chambre8.jpg" alt="Chambre de l'hôtel Neptune" class="img-circle" width="904" height="636"/>
<p>Chambre 8</p>
<br>
<br>
</div>

<div class="chambre">
<img src="images/chambre9.jpg" alt="Chambre de l'hôtel Neptune" class="img-circle" width="904" height="636"/>
<p>Chambre 9</p>
<br>
<br>
</div>

<div class="chambre">
<img src="images/chambre10.jpg" alt="Chambre de l'hôtel Neptune" class="img-circle" width="904" height="636"/>
<p>Chambre 10</p>
<br>
<br>
</div>

<div class="chambre">
<img src="images/chambre11.jpg" alt="Chambre de l'hôtel Neptune" class="img-circle" width="904" height="636"/>
<p>Chambre 11</p>
<br>
<br>
</div>

<div class="chambre">
<img src="images/chambre12.jpg" alt="Chambre de l'hôtel Neptune" class="img-circle" width="904" height="636"/>
<p>Chambre 12</p>
<br>
<br>
</div>

</center>

</body>
</html>